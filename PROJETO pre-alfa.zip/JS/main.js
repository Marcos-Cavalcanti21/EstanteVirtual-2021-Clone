//################# BANNER ###############//

let time = 10000,
    currentImgIndex = 0,
    images = document
                .querySelectorAll("#slider img"),
    max = images.length;


    function anteImg(){

        images[currentImgIndex]
            .classList.remove('selected')
    
        currentImgIndex--
    
        if(currentImgIndex <= 0){
            currentImgIndex = 3
        }
    
        images[currentImgIndex]
            .classList.add('selected')
    }

function proxImg(){

    images[currentImgIndex]
        .classList.remove('selected')

    currentImgIndex++

    if(currentImgIndex >= max){
        currentImgIndex = 0
    }

    images[currentImgIndex]
        .classList.add('selected')
}

function start(){
    setInterval(()=>{
        proxImg()
    },time)
}

window.addEventListener("load",start)

//############# FUNCTIONS ON FORMS ##########//

function esconde(){
    
}

function cadClient(){
    document.client.reset()
}